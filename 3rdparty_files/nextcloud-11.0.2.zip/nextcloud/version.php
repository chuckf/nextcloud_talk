<?php 
$OC_Version = array(11,0,2,7);
$OC_VersionString = '11.0.2';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  0 => 9,
  1 => 1,
);
$OC_Build = '2017-02-26T19:43:43+00:00 f299c9b2f4cb98b6dcd79943882740f9b72dc3c0';
$vendor = 'nextcloud';
